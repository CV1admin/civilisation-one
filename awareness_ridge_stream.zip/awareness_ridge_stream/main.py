from stream_bridge import start_quantime_stream

if __name__ == "__main__":
    start_quantime_stream()
