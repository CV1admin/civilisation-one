def demo():
    print('Hybrid demo placeholder')