# Stub for LLM interface
