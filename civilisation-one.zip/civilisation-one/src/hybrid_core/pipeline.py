# Human → LLM → Quantum → Classical → LLM pipeline
