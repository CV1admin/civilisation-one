# Stub for Qiskit subroutines
