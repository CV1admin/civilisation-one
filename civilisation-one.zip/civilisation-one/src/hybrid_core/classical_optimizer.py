# Stub for classical optimizer
