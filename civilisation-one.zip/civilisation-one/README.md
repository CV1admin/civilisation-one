# Hybrid Dominance 2025

This repo demonstrates when and why quantum-classical hybrid models outperform large language models (LLMs).

## Why Hybrids Exist

Quantum wins when the loss surface is shaped by physics.  
LLM wins when the loss surface is shaped by people.

## Canonical Hybrid Pipeline

1. Human → LLM  
2. LLM → Quantum  
3. Quantum → Classical  
4. Feedback into LLM

## Repo Layout

- `paper/`: LaTeX whitepaper  
- `src/`: Hybrid core logic (LLM, Quantum, Classical)  
- `notebooks/`: Demos of hybrid dominance conditions  
- `env/`: Environment setup  
- `tests/`: Unit tests  
- `.github/workflows`: CI pipeline  
